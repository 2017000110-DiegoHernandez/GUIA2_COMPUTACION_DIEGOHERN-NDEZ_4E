/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.g2.compu.diegohernandez;

/**
 *
 * @author Usuario
 */
public class G2COMPU17DIEGOHERNANDEZ {

    public static void main(String[] args) {
        jfrmcalc holaCP = new jfrmcalc();
        holaCP.setVisible(true);
    }
}
